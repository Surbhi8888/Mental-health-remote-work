import pandas as pd
import pickle
import requests
from io import StringIO
from flask import Flask, render_template

app = Flask(__name__)

# Load models for happiness
with open("linier_regressors_per_variable.pkl", "rb") as f:
    regressors = pickle.load(f)

with open("xgboost_model.pkl", "rb") as f:
    final_model = pickle.load(f)

# Load model for remote satisfaction
with open("remote_work_model.pkl", "rb") as f:
    remote_model = pickle.load(f)

with open("remote_work_encoders.pkl", "rb") as f:
    encoders = pickle.load(f)

with open("remote_work_columns.pkl", "rb") as f:
    remote_columns = pickle.load(f)

# Load mental health treatment model
import joblib
mh_model = joblib.load("mental_health_model.pkl")

with open("mental_health_encoders.pkl", "rb") as f:
    mh_encoders = pickle.load(f)

with open("mental_health_columns.pkl", "rb") as f:
    mh_columns = pickle.load(f)


# Load historical data
df = pd.read_csv("Copy of happiness_clean.csv")
features = ['GDP per capita', 'Social support', 'Healthy life expectancy']

# ----------------- ROUTES -----------------

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/insights')
def insights():
    return render_template('insights.html')

@app.route('/survey')
def survey():
    return render_template('survey.html')

@app.route('/prediction')
def prediction():
    return render_template('prediction.html')


@app.route('/predict_from_form')
def predict_from_google_form():
    try:
        csv_url = "https://docs.google.com/spreadsheets/d/e/2PACX-1vRVZ50CyMTVogbWYLKZXt7dDXxZP8weIkFX52maZTGuqtwRPrtsxEkG3W_MdtPZV3MLK31-ntvCajWh/pub?output=csv"
        country = fetch_latest_country(csv_url)
        inputs = predict_features(country)

        if None not in inputs:
            score = final_model.predict([inputs])[0]
            prediction = round(score, 3)
        else:
            prediction = "Not enough data to predict for this country."

    except Exception as e:
        country = "Unknown"
        prediction = f"Error: {str(e)}"

    return render_template("prediction.html", country=country, prediction=prediction)
    #return render_template("happiness_prediction.html", country=country, prediction=round(prediction, 3))

@app.route('/remote_satisfaction_from_form')
def remote_google_prediction():
    try:
        # Step 1: Fetch latest Google Form response
        csv_url = "https://docs.google.com/spreadsheets/d/e/2PACX-1vRVZ50CyMTVogbWYLKZXt7dDXxZP8weIkFX52maZTGuqtwRPrtsxEkG3W_MdtPZV3MLK31-ntvCajWh/pub?output=csv"
        df_form = pd.read_csv(csv_url)
        latest = df_form.iloc[-1]

        # Step 2: Map values to model input format
        raw_input = {
            'Age': int(latest["2- What is your age?\n(Enter a whole number, e.g., 30)"]),
            'Gender': latest["3- What is your gender? "].strip(),
            'Years_of_Experience': int(latest["5- How many years of experience do you have in your field? (Enter a whole number, e.g., 5)"]),
            'Hours_Worked_Per_Week': int(latest["4- How many hours do you work per week on average? (Enter a whole number, e.g., 40)"]),
            'Work_Location': latest["6- What is your work location type? "].strip(),
            'Stress_Level': latest["7-  How often do mental health issues interfere with your work? "].strip(),
            'Mental_Health_Condition': "None",  # Not collected → default
            'Access_to_Mental_Health_Resources': latest["9- Does your company provide mental health care options?  "].strip(),
            'Productivity_Change': "No Change",  # Not collected → default
            'Social_Isolation_Rating': 3,         # Defaulted mid
            'Company_Support_for_Remote_Work': 3, # Defaulted mid
            'Physical_Activity': "Weekly",        # Defaulted
            'Sleep_Quality': "Average",           # Defaulted
            'Region': "North America",            # Optional default
            'Industry': "IT",                     # Use a known category
            'Job_Role': "Software Engineer",      # Use a known category
        }

        # 👉 NEW BLOCK HERE
        input_df = pd.DataFrame([raw_input])
        input_encoded = pd.get_dummies(input_df)
        for col in remote_columns:
            if col not in input_encoded:
                input_encoded[col] = 0
        input_encoded = input_encoded[remote_columns]

        # Predict
        prediction_encoded = remote_model.predict(input_encoded)[0]
        probs = remote_model.predict_proba(input_encoded)[0]
        print("🧪 Probabilities:", probs)
        print("🧪 Classes:", remote_model.classes_)
        prediction_label = encoders['Satisfaction_with_Remote_Work'].inverse_transform([prediction_encoded])[0]

    except Exception as e:
        prediction_label = f"Error: {str(e)}"

    return render_template("remote_work_prediction.html", satisfaction=prediction_label)


# ----------------- HELPERS -----------------

def fetch_latest_country(csv_url):
    response = requests.get(csv_url)
    df_form = pd.read_csv(StringIO(response.text))
    possible_cols = [col for col in df_form.columns if "country" in col.lower()]
    if not possible_cols:
        raise ValueError("No column with 'country' found in form.")
    country_col = possible_cols[0]
    raw_input = df_form.iloc[-1][country_col].strip().lower()

    for train_country in df['Country'].unique():
        if train_country.strip().lower() == raw_input:
            return train_country.strip()
    return None


def predict_features(country):
    predicted = []
    latest_year = df[df['Country'] == country]['Year'].max()
    if pd.isna(latest_year):
        return [None] * 7
    next_year = int(latest_year + 1)

    for feature in features:
        if country in regressors[feature]:
            model = regressors[feature][country]
            pred = model.predict([[next_year]])[0]
            predicted.append(pred)
        else:
            predicted.append(df[feature].mean())

    for col in ['Freedom to make life choices', 'Generosity', 'Perceptions of corruption', 'Dystopia Residual']:
        if col in df.columns:
            country_data = df[df['Country'] == country][col].dropna()
            predicted.append(country_data.mean() if not country_data.empty else df[col].mean())
        else:
            predicted.append(0.0)
    return predicted


def safe_encode(value, encoder, default=None):
    """Encode only if value exists in training encoder, fallback to known default."""
    classes = encoder.classes_
    if value in classes:
        return encoder.transform([value])[0]
    elif default and default in classes:
        return encoder.transform([default])[0]
    else:
        return encoder.transform([classes[0]])[0]  # fallback to first seen label


@app.route('/mental_treatment_from_form')
def mental_health_treatment_prediction():
    try:
        csv_url = "https://docs.google.com/spreadsheets/d/e/2PACX-1vRVZ50CyMTVogbWYLKZXt7dDXxZP8weIkFX52maZTGuqtwRPrtsxEkG3W_MdtPZV3MLK31-ntvCajWh/pub?output=csv"
        df_form = pd.read_csv(csv_url)
        latest = df_form.iloc[-1]

        raw_input = {
            'Age': int(latest['2- What is your age?\n(Enter a whole number, e.g., 30)']),
            'Gender': latest['3- What is your gender? '].strip(),
            'Hours per week': int(latest['4- How many hours do you work per week on average? (Enter a whole number, e.g., 40)']),
            'Years of experience': int(latest['5- How many years of experience do you have in your field? (Enter a whole number, e.g., 5)']),
            'Work Location': latest['6- What is your work location type? '].strip(),
            'Interference': latest['7-  How often do mental health issues interfere with your work? '].strip(),
            'Family History': latest['8-  Do you have a family history of mental health issues? '].strip(),
            'Care Options': latest['9- Does your company provide mental health care options?  '].strip(),
            'Benefits': latest['10- Does your employer provide mental health benefits?'].strip()
        }

        input_df = pd.DataFrame([raw_input])
        for col in input_df.columns:
            if col in mh_encoders:
                le = mh_encoders[col]
                val = raw_input[col]
                input_df[col] = le.transform([val]) if val in le.classes_ else le.transform([le.classes_[0]])

        input_encoded = pd.get_dummies(input_df)
        for col in mh_columns:
            if col not in input_encoded:
                input_encoded[col] = 0
        input_encoded = input_encoded[mh_columns]

        treatment_prediction = mh_model.predict(input_encoded)[0]
        probs = mh_model.predict_proba(input_encoded)[0]
        print("🧪 Probabilities:", probs)
        print("🧪 Classes:", mh_model.classes_)

        treatment_result = "Yes" if treatment_prediction == 1 else "No"

    except Exception as e:
        treatment_result = f"Error: {str(e)}"

    return render_template("mental_tach_prediction.html", treatment=treatment_result)

